package com.virtusa.shopping.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shopping.models.Category;
import com.virtusa.shopping.repositories.CategoryRepository;

@Service//("CategoryRepository")
public class CategoryService
{
	@Autowired
	private CategoryRepository categoryRepository;	
	/*
	 * @Autowired(required = true) public void setEmployeeService(CategoryServiceRepository
	 * employeeServiceImpl) { this.categoryRepository = (CategoryRepository)
	 * employeeServiceImpl; }
	 * 
	 * @Transactional
	 */
	public Category saveCategory(Category category)
	{
		return categoryRepository.save(category);
	}
}
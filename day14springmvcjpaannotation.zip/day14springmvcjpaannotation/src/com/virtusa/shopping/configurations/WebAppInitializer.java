package com.virtusa.shopping.configurations;

import com.virtusa.shopping.configurations.JpaConfig;
import com.virtusa.shopping.configurations.WebMVCConfig;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

@ComponentScan(basePackages={"com.virtusa.shopping.*"})

public class WebAppInitializer 
      extends AbstractAnnotationConfigDispatcherServletInitializer {

  // Load database and spring security configuration
  @Override
  protected Class<?>[] getRootConfigClasses() {
    return new Class[] { JpaConfig.class };
  }

  // Load database and spring web configuration
  @Override
  protected Class<?>[] getServletConfigClasses() {
    return new Class[] { WebMVCConfig.class };
  }

  @Override
  protected String[] getServletMappings() {
    return new String[] { "/" };
  }

}
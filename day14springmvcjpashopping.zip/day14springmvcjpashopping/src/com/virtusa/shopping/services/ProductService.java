package com.virtusa.shopping.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shopping.models.Category;
import com.virtusa.shopping.models.Product;
import com.virtusa.shopping.repositories.ProductRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepo;
	@Autowired
	private CategoryService categoryService;
	
	public Product saveProduct(Product product, int categoryId)
	{
		Category category=categoryService.getCategoryById(categoryId);
		product.setCategory(category);
		return productRepo.save(product);
	}
	
	
	
	
	
}

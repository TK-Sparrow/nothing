package com.virtusa.shopping.services;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shopping.models.User;
import com.virtusa.shopping.repositories.UserRepository;

@Service

public class UserService {
    @Autowired
	private UserRepository userRepository;
	
	public User getUserByName(String userName)
	{
		
		return userRepository.getOne(userName);
		
	}
    
    
    
}
